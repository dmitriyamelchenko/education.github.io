const hello = `<h1>Hello World</h1>`;
document.body.innerHTML = hello;
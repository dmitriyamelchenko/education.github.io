# Vanilla JS Webpack Boilerplate

## What's inside

- Dev and Prod modes
- Dead code elimination (tree shaking)
- Image minification
- ES6, ES7
- ESLint
/*
  Add code above this comment
*/
if (module.hot) {
  module.hot.accept();
}
